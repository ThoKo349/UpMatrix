
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, ForeignKey
from datetime import datetime
from .db import Base

class Container(Base):
    __tablename__ = "containers"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    host = Column(String(255), nullable=False)
    port = Column(Integer, nullable=False, default=22)
    ssh_user = Column(String(100), nullable=False, default="root")
    ssh_key_path = Column(String(512), nullable=True)
    tags = Column(String(255), nullable=True)
    enabled = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Job(Base):
    __tablename__ = "jobs"
    id = Column(Integer, primary_key=True, index=True)
    type = Column(String(50), nullable=False)
    status = Column(String(20), nullable=False, default="queued")
    created_by = Column(String(100), nullable=True)
    started_at = Column(DateTime, nullable=True)
    finished_at = Column(DateTime, nullable=True)
    summary = Column(Text, nullable=True)

class JobStep(Base):
    __tablename__ = "job_steps"
    id = Column(Integer, primary_key=True, index=True)
    job_id = Column(Integer, ForeignKey("jobs.id"), nullable=False)
    container_id = Column(Integer, ForeignKey("containers.id"), nullable=False)
    status = Column(String(20), nullable=False, default="queued")
    stdout_snippet = Column(Text, nullable=True)
    stderr_snippet = Column(Text, nullable=True)
    duration_ms = Column(Integer, nullable=True)
    exit_code = Column(Integer, nullable=True)
    attempt = Column(Integer, nullable=False, default=1)

class SmtpSettings(Base):
    __tablename__ = "smtp_settings"
    id = Column(Integer, primary_key=True, index=True)
    enabled = Column(Boolean, default=False)
    host = Column(String(255), nullable=True)
    port = Column(Integer, nullable=True)
    encryption = Column(String(20), nullable=True)  # none|starttls|tls
    auth_mode = Column(String(20), nullable=True)   # none|login
    username = Column(String(255), nullable=True)
    password = Column(String(255), nullable=True)   # demo only
    from_address = Column(String(255), nullable=True)
    from_name = Column(String(255), nullable=True)
    reply_to = Column(String(255), nullable=True)
    subject_prefix = Column(String(100), nullable=True)
    default_recipients = Column(Text, nullable=True)
    max_emails_per_hour = Column(Integer, nullable=True)
    per_recipient_cooldown_minutes = Column(Integer, nullable=True)
    last_test_at = Column(DateTime, nullable=True)
    last_test_status = Column(String(20), nullable=True)
    last_error = Column(Text, nullable=True)
