
#!/usr/bin/env bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON=${PYTHON:-python3}
VENV="$APP_DIR/.venv"

echo "[1/4] Python venv anlegen..."
$PYTHON -m venv "$VENV"
source "$VENV/bin/activate"
pip install --upgrade pip
pip install -r "$APP_DIR/requirements.txt"

echo "[2/4] Systemd-Service schreiben..."
cat > "$APP_DIR/lxc-updater.service" << 'UNIT'
[Unit]
Description=UpMatrix Web
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
Environment="PYTHONUNBUFFERED=1"
WorkingDirectory=%h/lxc-updater
ExecStart=%h/lxc-updater/.venv/bin/uvicorn app.main:app --host 0.0.0.0 --port 8080
Restart=always
RestartSec=3
User=%i

[Install]
WantedBy=multi-user.target
UNIT

USER_NAME="$(id -un)"
SVC_PATH="/etc/systemd/system/lxc-updater@${USER_NAME}.service"
sudo cp "$APP_DIR/lxc-updater.service" "$SVC_PATH"
sudo systemctl daemon-reload
sudo systemctl enable "lxc-updater@${USER_NAME}.service"
sudo systemctl restart "lxc-updater@${USER_NAME}.service"

echo "[3/4] Hinweis: SSH-Auth per Key oder Passwort pro Container konfigurierbar."
echo "[4/4] Fertig. Service läuft auf Port 8080."
