
# UpMatrix (Passwort-Login Unterstützung)
- SSH-Auth: wahlweise **Key** oder **User/Pass** pro Container.
- Neuer UI-Toggle im Formular.
- Achtung: Passwortspeicherung nur zu Demo-Zwecken im Klartext. Für Produktion -> Secret Manager.
