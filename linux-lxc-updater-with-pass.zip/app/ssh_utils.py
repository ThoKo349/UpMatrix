
import paramiko, time

def _connect(client, host, port, user, key_path=None, password=None, timeout=15):
    kwargs = dict(hostname=host, port=port, username=user, timeout=timeout,
                  allow_agent=True, look_for_keys=True)
    if password:
        kwargs['password'] = password
        kwargs['look_for_keys'] = False
        kwargs['allow_agent'] = False
    if key_path and not password:
        kwargs['key_filename'] = key_path
    client.connect(**kwargs)

def run_apt_upgrade(host: str, port: int, user: str, key_path: str|None, password: str|None, timeout=600):
    start = time.time()
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        _connect(client, host, port, user, key_path=key_path, password=password, timeout=15)
        cmd = "sudo DEBIAN_FRONTEND=noninteractive apt-get update && sudo DEBIAN_FRONTEND=noninteractive apt-get -y -o Dpkg::Options::=--force-confnew upgrade"
        stdin, stdout, stderr = client.exec_command(cmd, get_pty=True, timeout=timeout)
        out = stdout.read().decode(errors="ignore")
        err = stderr.read().decode(errors="ignore")
        ec = stdout.channel.recv_exit_status()
        dur = int((time.time() - start) * 1000)
        return ec, out[-4000:], err[-4000:], dur
    except Exception as e:
        dur = int((time.time() - start) * 1000)
        return 255, "", str(e), dur
    finally:
        try: client.close()
        except Exception: pass

def ping_ssh(host: str, port: int, user: str, key_path: str|None, password: str|None):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        _connect(client, host, port, user, key_path=key_path, password=password, timeout=10)
        return True, "OK"
    except Exception as e:
        return False, str(e)
    finally:
        try: client.close()
        except Exception: pass
