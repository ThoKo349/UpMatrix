
function $(sel, root=document){ return root.querySelector(sel); }
async function fetchJSON(url, opts={}){
  const res = await fetch(url, Object.assign({headers:{'Accept':'application/json'}}, opts));
  if(!res.ok){
    let txt = await res.text().catch(()=> 'Fehler');
    try{ const obj = JSON.parse(txt); txt = obj.detail || txt }catch(e){}
    throw new Error(txt);
  }
  return res.json();
}
function el(tag, attrs={}, children=[]){
  const e = document.createElement(tag);
  for(const [k,v] of Object.entries(attrs)){
    if(k==='class') e.className = v;
    else if(k==='html') e.innerHTML = v;
    else e.setAttribute(k,v);
  }
  (Array.isArray(children)?children:[children]).forEach(c=>{
    if(typeof c === 'string') e.appendChild(document.createTextNode(c));
    else if(c) e.appendChild(c);
  });
  return e;
}

/* --- Dashboard logic --- */
async function loadContainers(){
  const tbody = document.querySelector('#tbl tbody');
  if(!tbody) return;
  tbody.innerHTML = '';
  const items = await fetchJSON('/api/containers');
  for(const c of items){
    const row = el('tr', {}, [
      el('td', {}, c.id.toString()),
      el('td', {}, c.name),
      el('td', {}, `${c.host}:${c.port}`),
      el('td', {}, c.ssh_user),
      el('td', {}, c.tags || ''),
      el('td', {}, (()=>{
        const wrap = el('span');
        const ping = el('button', {class:'btn'}, 'Ping');
        ping.addEventListener('click', async ()=>{
          ping.disabled = true;
          try{
            const res = await fetchJSON(`/api/containers/${c.id}/ping`, {method:'POST'});
            alert(res.ok ? 'SSH OK' : ('Fehler: '+res.message));
          }catch(e){ alert(e.message); }
          ping.disabled = false;
        });
        const delB = el('button', {class:'btn'}, 'Löschen');
        delB.addEventListener('click', async ()=>{
          if(!confirm('Container wirklich löschen?')) return;
          await fetchJSON(`/api/containers/${c.id}`, {method:'DELETE'});
          loadContainers();
        });
        wrap.append(ping, ' ', delB);
        return wrap;
      })())
    ]);
    tbody.appendChild(row);
  }
}
async function watchJob(jobId){
  const container = document.getElementById('jobs');
  if(!container) return;
  const card = el('div', {class:'job'});
  const head = el('div', {class:'job-header'}, [ el('div', {}, `Job #${jobId}`), el('div', {class:'muted'}, 'läuft...') ]);
  const log = el('div', {class:'log', id:`log-${jobId}`}, '');
  card.append(head, log);
  container.prepend(card);
  let done = false;
  while(!done){
    try{
      const j = await fetchJSON(`/api/jobs/${jobId}`);
      head.lastChild.textContent = `Status: ${j.status}`;
      const lines = [];
      j.steps.forEach(s=>{
        lines.push(`#${s.id} cid=${s.container_id} status=${s.status} exit=${s.exit_code ?? ''} dur=${s.duration_ms ?? ''}ms`);
        if(s.stderr_snippet) lines.push('ERR: '+s.stderr_snippet);
        if(s.stdout_snippet) lines.push('OUT: '+s.stdout_snippet);
        lines.push('');
      });
      log.textContent = lines.join('\n');
      done = (j.status === 'success' || j.status === 'failed');
      await new Promise(r=>setTimeout(r, 1500));
    }catch(e){
      log.textContent += `\n[Fehler beim Laden: ${e.message}]`;
      await new Promise(r=>setTimeout(r, 3000));
    }
  }
}
const formAdd = document.getElementById('form-add');
if(formAdd){
  formAdd.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const fd = new FormData(formAdd);
    try{
      await fetchJSON('/api/containers', {method:'POST', body: fd});
      formAdd.reset();
      document.getElementById('ssh_key_path').style.display = '';
      document.getElementById('ssh_password').style.display = 'none';
      loadContainers();
    }catch(e){ alert(e.message); }
  });
}
const btnUpdateAll = document.getElementById('btn-update-all');
if(btnUpdateAll){
  btnUpdateAll.addEventListener('click', async ()=>{
    if(!confirm('Alle aktivierten Container nacheinander updaten?')) return;
    try{
      const res = await fetchJSON('/api/jobs/update_all', {method:'POST'});
      watchJob(res.job_id);
    }catch(e){ alert(e.message); }
  });
}
const btnRefresh = document.getElementById('btn-refresh-containers');
if(btnRefresh){ btnRefresh.addEventListener('click', loadContainers); }
/* Toggle auth fields */
const authSel = document.getElementById('ssh_auth');
if(authSel){
  const keyField = document.getElementById('ssh_key_path');
  const passField = document.getElementById('ssh_password');
  const sync = ()=>{
    if(authSel.value === 'password'){ keyField.style.display='none'; passField.style.display=''; }
    else { keyField.style.display=''; passField.style.display='none'; }
  };
  authSel.addEventListener('change', sync); sync();
}

/* Settings (SMTP) */
async function loadSmtp(){
  const form = document.getElementById('smtp-form');
  if(!form) return;
  const cfg = await fetchJSON('/api/settings/smtp');
  const set = (k,v)=>{
    const f = form.querySelector(`[name="${k}"]`);
    if(!f) return;
    if(f.type === 'checkbox') f.checked = !!v;
    else f.value = (v ?? '');
  };
  ['enabled','host','port','encryption','auth_mode','username','from_name','from_address','reply_to','subject_prefix','default_recipients'].forEach(k=>set(k, cfg[k]));
  const status = document.getElementById('smtp-status');
  status.textContent = cfg.last_test_status ? `Letzter Test: ${cfg.last_test_status} (${cfg.last_test_at || ''}) ${cfg.last_error || ''}` : 'Noch kein Test durchgeführt.';
}
const smtpSave = document.getElementById('btn-smtp-save');
if(smtpSave){
  smtpSave.addEventListener('click', async ()=>{
    const form = document.getElementById('smtp-form');
    const payload = {};
    ['enabled','host','port','encryption','auth_mode','username','password','from_name','from_address','reply_to','subject_prefix','default_recipients'].forEach(k=>{
      const e = form.querySelector(`[name="${k}"]`); if(!e) return;
      payload[k] = (e.type === 'checkbox') ? e.checked : e.value;
    });
    try{
      await fetchJSON('/api/settings/smtp', {method:'PATCH', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
      alert('Gespeichert.'); loadSmtp();
    }catch(e){ alert(e.message); }
  });
}
const smtpTestConn = document.getElementById('btn-smtp-test-conn');
if(smtpTestConn){
  smtpTestConn.addEventListener('click', async ()=>{
    try{ await fetchJSON('/api/settings/smtp/test-connection', {method:'POST'}); alert('Verbindung OK'); loadSmtp(); }
    catch(e){ alert(e.message); }
  });
}
const smtpTestMail = document.getElementById('btn-smtp-test-mail');
if(smtpTestMail){
  smtpTestMail.addEventListener('click', async ()=>{
    const to = document.getElementById('test-to').value;
    if(!to) return alert('Bitte Zieladresse eingeben.');
    const fd = new FormData(); fd.append('to', to);
    try{ await fetchJSON('/api/settings/smtp/test-email', {method:'POST', body: fd}); alert('Testmail gesendet.'); }
    catch(e){ alert(e.message); }
  });
}

/* Init */
if(document.getElementById('tbl')) loadContainers();
if(document.getElementById('smtp-form')) loadSmtp();
