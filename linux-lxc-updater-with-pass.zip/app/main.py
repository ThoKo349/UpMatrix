
from fastapi import FastAPI, Request, Depends, HTTPException, Form
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy import select
from datetime import datetime
import threading

from .db import Base, engine, get_db
from .models import Container, Job, JobStep, SmtpSettings
from .ssh_utils import run_apt_upgrade, ping_ssh
from .notifier import send_email, test_smtp_connection

app = FastAPI(title="UpMatrix")
app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")

Base.metadata.create_all(bind=engine)

# UI
@app.get("/", response_class=HTMLResponse)
def index(request: Request, db: Session = Depends(get_db)):
    containers = db.execute(select(Container).order_by(Container.id.desc())).scalars().all()
    jobs = db.execute(select(Job).order_by(Job.id.desc()).limit(10)).scalars().all()
    total = len(containers)
    enabled = sum(1 for c in containers if c.enabled)
    last_job = jobs[0] if jobs else None
    return templates.TemplateResponse("index.html", {
        "request": request,
        "containers": containers,
        "jobs": jobs,
        "stats": {"total": total, "enabled": enabled, "last_job_status": getattr(last_job, "status", "—")}
    })

@app.get("/settings", response_class=HTMLResponse)
def settings_page(request: Request, db: Session = Depends(get_db)):
    smtp = db.get(SmtpSettings, 1)
    return templates.TemplateResponse("settings.html", {"request": request, "smtp": smtp})

# API: Containers
@app.get("/api/containers")
def list_containers(db: Session = Depends(get_db)):
    items = db.execute(select(Container).order_by(Container.id.desc())).scalars().all()
    return [{
        "id": c.id, "name": c.name, "host": c.host, "port": c.port, "ssh_user": c.ssh_user,
        "ssh_key_path": c.ssh_key_path, "ssh_auth": c.ssh_auth, "tags": c.tags, "enabled": c.enabled
    } for c in items]

@app.post("/api/containers")
def create_container(name: str = Form(...), host: str = Form(...), port: int = Form(22),
                     ssh_user: str = Form("root"), ssh_key_path: str = Form("~/.ssh/id_rsa"),
                     ssh_auth: str = Form("key"), ssh_password: str = Form(""),
                     tags: str = Form(""), enabled: bool = Form(True), db: Session = Depends(get_db)):
    ssh_auth = ssh_auth if ssh_auth in ("key","password") else "key"
    if ssh_auth == "password" and not ssh_password:
        raise HTTPException(400, "Passwort erforderlich für Passwort-Login.")
    c = Container(
        name=name.strip(), host=host.strip(), port=port,
        ssh_user=ssh_user.strip(),
        ssh_key_path=(ssh_key_path.strip() if ssh_auth=="key" else None),
        ssh_auth=ssh_auth,
        ssh_password=(ssh_password if ssh_auth=="password" else None),
        tags=tags.strip(), enabled=enabled
    )
    db.add(c); db.commit(); db.refresh(c)
    return {"ok": True, "id": c.id}

@app.delete("/api/containers/{cid}")
def delete_container(cid: int, db: Session = Depends(get_db)):
    c = db.get(Container, cid)
    if not c: raise HTTPException(404)
    db.delete(c); db.commit()
    return {"ok": True}

@app.post("/api/containers/{cid}/ping")
def ping_container(cid: int, db: Session = Depends(get_db)):
    c = db.get(Container, cid)
    if not c: raise HTTPException(404)
    ok, msg = ping_ssh(c.host, c.port, c.ssh_user, c.ssh_key_path, c.ssh_password if c.ssh_auth=="password" else None)
    return {"ok": ok, "message": msg}

# Jobs
def _notify_job_result(db: Session, job: Job):
    settings = db.get(SmtpSettings, 1)
    if not settings or not settings.enabled: return
    recipients = [r.strip() for r in (settings.default_recipients or "").split(",") if r.strip()]
    if not recipients: return
    steps = db.execute(select(JobStep).where(JobStep.job_id == job.id)).scalars().all()
    total = len(steps); failed = len([s for s in steps if s.exit_code and s.exit_code != 0]); ok = total - failed
    subject = f"{settings.subject_prefix or '[LXC]'} Job #{job.id} {job.status.upper()} ({ok}/{total} OK)"
    lines = [f"Job {job.id} – Status: {job.status}", f"Gestartet: {job.started_at}", f"Fertig: {job.finished_at}", f"Container OK: {ok}, Fehler: {failed}"]
    for s in steps[:10]:
        cname = db.get(Container, s.container_id).name if s.container_id else "?"
        lines.append(f"- {cname}: exit {s.exit_code}, {s.status}")
    body = "\n".join(lines); html = "<br>".join(lines)
    try:
        send_email(settings.host, settings.port or (465 if settings.encryption=='tls' else 587),
                   settings.encryption or "starttls",
                   settings.username, settings.password,
                   settings.from_address, settings.from_name,
                   recipients, subject, body, html)
    except Exception: pass

def _run_job(job_id: int):
    local = next(get_db())
    job = local.get(Job, job_id)
    if not job: return
    job.status = "running"; job.started_at = datetime.utcnow(); local.commit()
    steps = local.execute(select(JobStep).where(JobStep.job_id==job_id)).scalars().all()
    any_fail = False
    for s in steps:
        c = local.get(Container, s.container_id)
        s.status = "running"; local.commit()
        ec, out, err, dur = run_apt_upgrade(c.host, c.port, c.ssh_user,
                                            c.ssh_key_path, c.ssh_password if c.ssh_auth=="password" else None)
        s.exit_code = ec; s.duration_ms = dur; s.stdout_snippet = out; s.stderr_snippet = err
        s.status = "success" if ec == 0 else "failed"; any_fail = any_fail or (ec != 0)
        local.commit()
    job.finished_at = datetime.utcnow(); job.status = "failed" if any_fail else "success"; local.commit()
    _notify_job_result(local, job)

@app.post("/api/jobs/update_all")
def update_all(db: Session = Depends(get_db)):
    containers = db.execute(select(Container).where(Container.enabled==True).order_by(Container.id)).scalars().all()
    if not containers: raise HTTPException(400, "Keine Container vorhanden oder alle deaktiviert.")
    job = Job(type="update_all", status="queued", created_by="web")
    db.add(job); db.commit(); db.refresh(job)
    for c in containers:
        db.add(JobStep(job_id=job.id, container_id=c.id, status="queued"))
    db.commit()
    threading.Thread(target=_run_job, args=(job.id,), daemon=True).start()
    return {"ok": True, "job_id": job.id}

@app.get("/api/jobs/{job_id}")
def job_status(job_id: int, db: Session = Depends(get_db)):
    job = db.get(Job, job_id)
    if not job: raise HTTPException(404)
    steps = db.execute(select(JobStep).where(JobStep.job_id==job_id)).scalars().all()
    return {
        "id": job.id, "type": job.type, "status": job.status,
        "started_at": job.started_at, "finished_at": job.finished_at,
        "steps": [{
            "id": s.id, "container_id": s.container_id, "status": s.status,
            "exit_code": s.exit_code, "duration_ms": s.duration_ms,
            "stdout_snippet": s.stdout_snippet, "stderr_snippet": s.stderr_snippet
        } for s in steps]
    }

# SMTP settings
@app.get("/api/settings/smtp")
def get_smtp(db: Session = Depends(get_db)):
    s = db.get(SmtpSettings, 1)
    if not s:
        s = SmtpSettings(id=1, enabled=False, encryption="starttls", subject_prefix="[LXC-Updates]")
        db.add(s); db.commit(); db.refresh(s)
    return {
        "enabled": s.enabled, "host": s.host, "port": s.port,
        "encryption": s.encryption, "auth_mode": s.auth_mode,
        "username": s.username, "from_address": s.from_address,
        "from_name": s.from_name, "reply_to": s.reply_to,
        "subject_prefix": s.subject_prefix, "default_recipients": s.default_recipients,
        "last_test_at": s.last_test_at, "last_test_status": s.last_test_status, "last_error": s.last_error
    }

@app.patch("/api/settings/smtp")
async def patch_smtp(payload: dict, db: Session = Depends(get_db)):
    s = db.get(SmtpSettings, 1)
    if not s:
        s = SmtpSettings(id=1); db.add(s); db.commit(); db.refresh(s)
    for k, v in payload.items():
        if hasattr(s, k): setattr(s, k, v)
    db.commit(); db.refresh(s)
    return {"ok": True}

@app.post("/api/settings/smtp/test-connection")
def smtp_test_connection_endpoint(db: Session = Depends(get_db)):
    s = db.get(SmtpSettings, 1)
    if not s or not s.host or not s.port: raise HTTPException(400, "SMTP unvollständig konfiguriert.")
    try:
        test_smtp_connection(s.host, s.port, s.encryption or "starttls", s.username, s.password)
        s.last_test_status = "ok"; s.last_error = None
    except Exception as e:
        s.last_test_status = "failed"; s.last_error = str(e); db.commit()
        raise HTTPException(500, f"Test fehlgeschlagen: {e}")
    finally:
        s.last_test_at = datetime.utcnow(); db.commit()
    return {"ok": True, "status": s.last_test_status}

@app.post("/api/settings/smtp/test-email")
def smtp_test_email(to: str = Form(...), db: Session = Depends(get_db)):
    s = db.get(SmtpSettings, 1)
    if not s or not (s.enabled and s.host and s.port and s.from_address):
        raise HTTPException(400, "SMTP ist nicht vollständig/aktiv konfiguriert.")
    subject = f"{s.subject_prefix or '[LXC]'} Testmail"
    body = "Dies ist eine Testmail von UpMatrix."
    try:
        send_email(s.host, s.port or (465 if s.encryption=='tls' else 587),
                   s.encryption or "starttls",
                   s.username, s.password,
                   s.from_address, s.from_name,
                   [to], subject, body, f"<p>{body}</p>")
    except Exception as e:
        raise HTTPException(500, f"Versand fehlgeschlagen: {e}")
    return {"ok": True}
