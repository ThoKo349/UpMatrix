
# LXC Updater (Web)

Ein kleines Webtool, um Linux-(LXC-)Container zu verwalten und per SSH nacheinander `apt-get update && apt-get upgrade -y` auszuführen. Inklusive SMTP-Benachrichtigungen (konfigurierbar im Web UI) und Test-Buttons.

## Schnellstart (Ubuntu 22.04/24.04)

```bash
sudo apt update
sudo apt install -y python3-venv python3-pip git
git clone <REPO ODER ARCHIV> lxc-updater
cd lxc-updater
./install.sh
```

Danach läuft der Dienst als `lxc-updater` auf Port **8080**: http://SERVER:8080

> **Hinweis**: Standardmäßig nutzt das Tool Key-basierte Auth (Pfad im UI angeben). Stelle sicher, dass der Server, auf dem dieses Tool läuft, SSH-Zugriff auf die Container hat (z. B. via Jump Host/Firewall-Regeln).

## Features

- Weboberfläche mit Tabelle: Container hinzufügen/löschen, „Update all“.
- Jobs mit Status/Logs (seriell, ein Container nach dem anderen).
- SMTP-Settings im UI, „Verbindung testen“ & „Testmail senden“.
- SQLite-Datenbank, kein extra Dienst nötig.

## Ordnerstruktur

- `app/` – FastAPI-Anwendung
- `app.db` – SQLite-Datenbank (wird automatisch erzeugt)
- `lxc-updater.service` – Systemd Unit
- `install.sh` – Installer (Venv, Service, Start)
- `requirements.txt`

## Systemd-Befehle

```bash
sudo systemctl status lxc-updater
sudo journalctl -u lxc-updater -f
sudo systemctl restart lxc-updater
```

## Sicherheit

- In dieser Demo wird das SMTP-Passwort im Klartext in SQLite gespeichert. Für Produktion: Secret-Manager/KMS verwenden.
- Stelle sicher, dass der angegebene SSH-Key-Pfad nur für den Service-User lesbar ist.
- Setze eine Firewall vor den Webport oder reverse proxy mit Auth, wenn erforderlich.
```

