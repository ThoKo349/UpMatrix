
async function fetchJSON(url, opts={}){
  const res = await fetch(url, Object.assign({headers: {'Accept': 'application/json'}}, opts));
  if(!res.ok){ throw new Error(await res.text()) }
  return res.json();
}

function el(tag, attrs={}, children=[]) {
  const e = document.createElement(tag);
  Object.entries(attrs).forEach(([k,v])=> {
    if(k==='class') e.className = v;
    else if (k==='html') e.innerHTML = v;
    else e.setAttribute(k, v);
  });
  (Array.isArray(children) ? children : [children]).forEach(c=> {
    if (typeof c === 'string') e.appendChild(document.createTextNode(c));
    else if (c) e.appendChild(c);
  });
  return e;
}

async function loadContainers(){
  const tbody = document.querySelector('#tbl tbody');
  tbody.innerHTML='';
  const items = await fetchJSON('/api/containers');
  items.forEach(c=>{
    const tr = el('tr',{},[
      el('td',{},c.id.toString()),
      el('td',{},c.name),
      el('td',{},`${c.host}:${c.port}`),
      el('td',{},`${c.ssh_user}`),
      el('td',{},c.tags||''),
      el('td',{},[
        el('button',{},'Ping').addEventListener? (function(){
          const b = el('button',{},'Ping');
          b.addEventListener('click', async ()=>{
            b.disabled = true;
            try{
              const res = await fetchJSON(`/api/containers/${c.id}/ping`, {method:'POST'});
              alert(res.ok ? 'SSH OK' : ('Fehler: '+res.message));
            }catch(err){ alert(err); }
            b.disabled = false;
          });
          return b;
        })() : null,
        ' ',
        (function(){
          const b = el('button',{},'Löschen');
          b.addEventListener('click', async ()=>{
            if(!confirm('Container löschen?')) return;
            await fetchJSON(`/api/containers/${c.id}`, {method:'DELETE'});
            loadContainers();
          });
          return b;
        })()
      ])
    ]);
    tbody.appendChild(tr);
  });
}

document.getElementById('form-add').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const fd = new FormData(e.target);
  try{
    await fetchJSON('/api/containers', {method:'POST', body: fd});
    e.target.reset();
    loadContainers();
  }catch(err){ alert(err); }
});

document.getElementById('btn-update-all').addEventListener('click', async ()=>{
  if(!confirm('Alle aktivierten Container nacheinander updaten?')) return;
  try{
    const res = await fetchJSON('/api/jobs/update_all', {method:'POST'});
    watchJob(res.job_id);
  }catch(err){ alert(err); }
});

async function loadJobs(){
  // simplistic: refresh latest job id shown in page template via server-rendered 'jobs' list? We'll just fetch via watchJob if needed.
}

async function watchJob(jobId){
  const container = document.getElementById('jobs');
  const card = el('div', {class:'job'},[el('div',{},`Job #${jobId} ...`), el('div',{class:'log', id:`log-${jobId}`}, '')]);
  container.prepend(card);
  let done = false;
  while(!done){
    try{
      const j = await fetchJSON(`/api/jobs/${jobId}`);
      card.firstChild.textContent = `Job #${j.id} – Status: ${j.status}`;
      const lines = [];
      j.steps.forEach(s=>{
        lines.push(`#${s.id} cid=${s.container_id} status=${s.status} exit=${s.exit_code ?? ''} dur=${s.duration_ms ?? ''}ms`);
        if (s.stderr_snippet) lines.push('ERR: '+s.stderr_snippet);
        if (s.stdout_snippet) lines.push('OUT: '+s.stdout_snippet);
        lines.push('');
      });
      document.getElementById(`log-${jobId}`).textContent = lines.join('\n');
      done = (j.status === 'success' || j.status === 'failed');
      await new Promise(r=>setTimeout(r, 2000));
    }catch(err){
      document.getElementById(`log-${jobId}`).textContent += `\n[Fehler beim Laden: ${err}]`;
      await new Promise(r=>setTimeout(r, 4000));
    }
  }
}

async function loadSmtp(){
  const cfg = await fetchJSON('/api/settings/smtp');
  const f = document.getElementById('smtp-form');
  ['enabled','host','port','encryption','auth_mode','username','from_name','from_address','reply_to','subject_prefix','default_recipients'].forEach(k=>{
    const elmt = f.querySelector(`[name="${k}"]`);
    if(!elmt) return;
    if(elmt.type==='checkbox') elmt.checked = !!cfg[k];
    else elmt.value = cfg[k] ?? '';
  });
  const status = document.getElementById('smtp-status');
  if (cfg.last_test_status){
    status.textContent = `Letzter Test: ${cfg.last_test_status} (${cfg.last_test_at || ''}) ${cfg.last_error || ''}`;
  }
}

document.getElementById('btn-smtp-save').addEventListener('click', async ()=>{
  const f = document.getElementById('smtp-form');
  const payload = {};
  ['enabled','host','port','encryption','auth_mode','username','password','from_name','from_address','reply_to','subject_prefix','default_recipients'].forEach(k=>{
    const elmt = f.querySelector(`[name="${k}"]`);
    if(!elmt) return;
    payload[k] = (elmt.type==='checkbox') ? elmt.checked : elmt.value;
  });
  try{
    await fetchJSON('/api/settings/smtp', {method:'PATCH', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
    alert('Gespeichert.');
    loadSmtp();
  }catch(err){ alert(err); }
});

document.getElementById('btn-smtp-test-conn').addEventListener('click', async ()=>{
  try{
    const res = await fetchJSON('/api/settings/smtp/test-connection', {method:'POST'});
    alert('Verbindung OK');
    loadSmtp();
  }catch(err){ alert('Fehler: '+err); }
});

document.getElementById('btn-smtp-test-mail').addEventListener('click', async ()=>{
  const to = document.getElementById('test-to').value;
  if(!to) return alert('Bitte Zieladresse eingeben.');
  const fd = new FormData();
  fd.append('to', to);
  try{
    await fetchJSON('/api/settings/smtp/test-email', {method:'POST', body: fd});
    alert('Testmail gesendet.');
  }catch(err){ alert('Fehler: '+err); }
});

loadContainers();
loadSmtp();
