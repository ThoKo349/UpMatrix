
import paramiko
import time

def run_apt_upgrade(host: str, port: int, user: str, key_path: str, timeout=600):
    """
    Returns (exit_code, stdout, stderr, duration_ms)
    """
    start = time.time()
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(hostname=host, port=port, username=user, key_filename=key_path, timeout=15, allow_agent=True, look_for_keys=True)
        cmd = "sudo DEBIAN_FRONTEND=noninteractive apt-get update && sudo DEBIAN_FRONTEND=noninteractive apt-get -y -o Dpkg::Options::=--force-confnew upgrade"
        stdin, stdout, stderr = client.exec_command(cmd, get_pty=True, timeout=timeout)
        out = stdout.read().decode(errors="ignore")
        err = stderr.read().decode(errors="ignore")
        ec = stdout.channel.recv_exit_status()
        dur = int((time.time() - start) * 1000)
        return ec, out[-4000:], err[-4000:], dur
    except Exception as e:
        dur = int((time.time() - start) * 1000)
        return 255, "", str(e), dur
    finally:
        try:
            client.close()
        except Exception:
            pass

def ping_ssh(host: str, port: int, user: str, key_path: str) -> tuple[bool, str]:
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(hostname=host, port=port, username=user, key_filename=key_path, timeout=10, allow_agent=True, look_for_keys=True)
        return True, "OK"
    except Exception as e:
        return False, str(e)
    finally:
        try:
            client.close()
        except Exception:
            pass
