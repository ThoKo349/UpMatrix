
import smtplib, ssl
from email.message import EmailMessage
from datetime import datetime
from typing import List, Optional

def _build_message(subject: str, body_text: str, html: Optional[str], from_addr: str, from_name: str|None, to_addrs: List[str], reply_to: str|None):
    msg = EmailMessage()
    msg['Subject'] = subject
    msg['From'] = f"{from_name} <{from_addr}>" if from_name else from_addr
    msg['To'] = ", ".join(to_addrs)
    if reply_to:
        msg['Reply-To'] = reply_to
    msg.set_content(body_text)
    if html:
        msg.add_alternative(html, subtype='html')
    return msg

def send_email(host: str, port: int, encryption: str, username: str|None, password: str|None,
               from_addr: str, from_name: str|None, to_addrs: List[str], subject: str,
               body_text: str, html: Optional[str]=None):
    msg = _build_message(subject, body_text, html, from_addr, from_name, to_addrs, None)
    if encryption == "tls":
        context = ssl.create_default_context()
        with smtplib.SMTP_SSL(host=host, port=port, context=context, timeout=15) as server:
            if username and password:
                server.login(username, password)
            server.send_message(msg)
    else:
        with smtplib.SMTP(host=host, port=port, timeout=15) as server:
            if encryption == "starttls":
                context = ssl.create_default_context()
                server.starttls(context=context)
            if username and password:
                server.login(username, password)
            server.send_message(msg)

def test_smtp_connection(host: str, port: int, encryption: str, username: str|None, password: str|None):
    # Connection + optional AUTH, no mail send
    if encryption == "tls":
        context = ssl.create_default_context()
        with smtplib.SMTP_SSL(host=host, port=port, context=context, timeout=10) as server:
            if username and password:
                server.login(username, password)
    else:
        with smtplib.SMTP(host=host, port=port, timeout=10) as server:
            if encryption == "starttls":
                context = ssl.create_default_context()
                server.starttls(context=context)
            if username and password:
                server.login(username, password)
